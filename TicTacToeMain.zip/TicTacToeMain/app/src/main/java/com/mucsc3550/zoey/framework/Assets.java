package com.mucsc3550.zoey.framework;

public class Assets {
    public static Pixmap background;
    public static Pixmap logo;
    public static Pixmap mainMenu;
    public static Pixmap buttons;
    public static Pixmap text;
    public static Pixmap tic_tac_toe_board;
    public static Pixmap scoreboard;
    public static Pixmap help1;
    public static Pixmap help2;
    public static Pixmap help3;
    public static Pixmap numbers;
    public static Pixmap pause;
    public static Pixmap X;
    public static Pixmap O;
    public static Sound click;
    public static Sound winGame;
    public static Sound loseGame;
    public static Pixmap help4;
    public static Pixmap wintext;
    public static Pixmap losetext;
    public static Pixmap drawtext;
    public static Pixmap highScores;
}

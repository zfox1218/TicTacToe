package com.mucsc3550.zoey.framework;

public class LoadingScreen extends Screen {
    public LoadingScreen(Game game) {
        super(game);
    }

    public void update(double deltaTime) {
        Graphics g = game.getGraphics();
        Assets.background = g.newPixmap("Background.png", Graphics.PixmapFormat.RGB565);
        Assets.logo = g.newPixmap("Logo.png", Graphics.PixmapFormat.ARGB4444);
        Assets.mainMenu = g.newPixmap("MainMenu.png", Graphics.PixmapFormat.ARGB4444);;
        Assets.buttons = g.newPixmap("Buttons2.png", Graphics.PixmapFormat.ARGB4444);
        Assets.help1 = g.newPixmap("Help Screen 1.png", Graphics.PixmapFormat.ARGB4444);
        Assets.help2 = g.newPixmap("Help Screen 2.png", Graphics.PixmapFormat.ARGB4444);
        Assets.help3 = g.newPixmap("Help Screen 3.png", Graphics.PixmapFormat.ARGB4444);
        Assets.numbers = g.newPixmap("Numbers.png", Graphics.PixmapFormat.ARGB4444);
        Assets.scoreboard=g.newPixmap("Scoreboard.png", Graphics.PixmapFormat.ARGB4444);
        Assets.tic_tac_toe_board=g.newPixmap("TicTacToeBoard.png", Graphics.PixmapFormat.ARGB4444);
        Assets.X=g.newPixmap("X.png", Graphics.PixmapFormat.ARGB4444);
        Assets.text=g.newPixmap("Text.png", Graphics.PixmapFormat.ARGB4444);
        Assets.O=g.newPixmap("O.png", Graphics.PixmapFormat.ARGB4444);
        Assets.help4=g.newPixmap("Help Screen 4.png", Graphics.PixmapFormat.ARGB4444);
        Assets.wintext=g.newPixmap("WinText.png", Graphics.PixmapFormat.ARGB4444);
        Assets.losetext=g.newPixmap("LoseText.png", Graphics.PixmapFormat.ARGB4444);
        Assets.drawtext=g.newPixmap("DrawText.png", Graphics.PixmapFormat.ARGB4444);
        Assets.highScores=g.newPixmap("High Scores.png", Graphics.PixmapFormat.ARGB4444);
        Assets.click = game.getAudio().newSound("Menu_Selection_Click.ogg");
        Assets.winGame = game.getAudio().newSound("applause.ogg");
        Assets.loseGame = game.getAudio().newSound("GAMEOVER.ogg");
        Settings.load(game.getFileIO());
        game.setScreen(new MainMenuScreen(game));
    }

    @Override
    public void present(double deltaTime) {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void dispose() {}
}

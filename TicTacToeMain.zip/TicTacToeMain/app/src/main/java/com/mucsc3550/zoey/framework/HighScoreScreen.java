package com.mucsc3550.zoey.framework;

import android.content.res.AssetFileDescriptor;
import android.text.method.Touch;
import com.mucsc3550.zoey.framework.Graphics;
import com.mucsc3550.zoey.framework.Game;
import com.mucsc3550.zoey.framework.Screen;
import com.mucsc3550.zoey.framework.Input.TouchEvent;
import java.util.List;
import java.util.Set;

public class HighScoreScreen extends Screen {
    int lines[] = new int[4];

    public HighScoreScreen(Game game) {
        super(game);

        for (int i = 3; i>=0; i--) {
            lines[i] = Settings.highscores[i];
        }
    }

    @Override
    public void update(double deltaTime) {
        List<TouchEvent> touchEvents = game.getInput().getTouchEvents();

        int len = touchEvents.size();
        for (int i = 0; i<len; i++) {
            TouchEvent event = touchEvents.get(i);
            if(event.type == TouchEvent.TOUCH_UP) {
                if(inBounds(event, 0, 410, 66, 61)) {
                    Settings.soundEnabled = !Settings.soundEnabled;
                    if(Settings.soundEnabled) Assets.click.play(1);
                }
                if (inBounds(event, 257, 0, 63, 60)) {
                    if (Settings.soundEnabled) Assets.click.play(1);
                    game.setScreen(new MainMenuScreen(game));
                }
                    return;
                }
            }
        }

    @Override
    public void present(double deltaTime) {
        Graphics g = game.getGraphics();
        g.drawPixmap(Assets.background, 0, 0);
        g.drawPixmap(Assets.highScores, 35, 50);
        g.drawPixmap(Assets.scoreboard, 50, 150);
        g.drawPixmap(Assets.buttons, 250, 0, 0, 0, 63, 60);
        if (Settings.soundEnabled)
            g.drawPixmap(Assets.buttons, 0, 410, 63, 0, 66, 61);
        else
            g.drawPixmap(Assets.buttons, 0, 410, 65, 68, 64, 61);




        drawText(g, lines[0], 132, 245);
        drawText(g, lines[1], 205, 245);
        drawText(g, lines[2], 132, 296);
        drawText(g, lines[3], 205, 296);

    }

    private void drawText(Graphics g, int line, int x, int y) {
        String lines=Integer.toString(line);
        int len = lines.length();
        for(int i = 0; i < len; i++) {
            char character = lines.charAt(i);

            int srcX = 0;
            int srcWidth = 0;

            if(character=='0'){
                srcX=2;
            }
            else {
                srcX = (character - '0') * 19;
            }
            srcWidth = 17;
            g.drawPixmap(Assets.numbers, x, y, srcX, 0, srcWidth, 32);
            x+= srcWidth;
        }
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void dispose() {}
    private boolean inBounds(TouchEvent event, int x, int y, int width, int height) {
        if(event.x > x && event.x < x + width - 1 && event.y > y && event.y < y + height - 1) {
            return true;
        }
        else
            return false;
    }}


package com.mucsc3550.zoey.framework;
import java.lang.reflect.Array;
import java.util.List;
import java.util.Random;
import android.util.Log;
import com.mucsc3550.zoey.framework.impl.AndroidGame;

import static android.R.attr.x;
import static android.R.attr.y;

public class GamePlay extends Screen {
    public static boolean  gameOver = false;

    enum GameState {Running, GameOver}

    GameState state = GameState.Running;
    String win="null";
    String user="null";
    String computer="null";
    int count=9;
    String currentBoard[][]={
        {null, null, null},
        {null, null, null},
        {null, null, null}};
    int xCords[] = {41, 128, 216};
    int yCords[] = {120, 202, 279};


    public GamePlay(Game game) {
        super(game);
        gameOver = false;
        state = GameState.Running;
        drawGameWorld();

    }

    @Override
    public void update(double deltaTime) {
        List<Input.TouchEvent> touchEvents = game.getInput().getTouchEvents();

        if (state == GameState.Running) {
            updateRunning(touchEvents);

        }

        if (state == GameState.GameOver) {
            updateGameOver(touchEvents);

        }
    }

    private void updateRunning(List<Input.TouchEvent> touchEvents) {
        int len = touchEvents.size();
        for (int i = 0; i < len; i++) {
            Input.TouchEvent event = touchEvents.get(i);
            if (event.type == Input.TouchEvent.TOUCH_UP) {
                if (inBounds(event, 257, 0, 63, 60)) {
                    if (Settings.soundEnabled) Assets.click.play(1);
                    game.setScreen(new MainMenuScreen(game));
                }
                if (user.equals("null")) {
                    if (inBounds(event, 130, 350, 63, 59)) {
                        user = "X";
                        computer = "O";
                    }
                    if (inBounds(event, 130, 400, 60, 58)) {
                        user = "O";
                        computer = "X";
                    }
                }
                if (user.equals("X") || user.equals("O")) {
                    if (inBounds(event, 35, 120, 250, 225)) {
                        getSquare(event.x, event.y);
                        if (Settings.soundEnabled) Assets.click.play(1);
                            }
                        }
            }
        }
        if(gameOver) {
            state = GameState.GameOver;
        }
}

    private void updateGameOver(List<Input.TouchEvent> touchEvents) {
        int len = touchEvents.size();
        for (int i = 0; i < len; i++) {
            Input.TouchEvent event = touchEvents.get(i);
            if (event.type == Input.TouchEvent.TOUCH_UP) {
                if (inBounds(event, 257, 0, 63, 60)) {
                    if (Settings.soundEnabled) Assets.click.play(1);
                    game.setScreen(new MainMenuScreen(game));
                }  }

    }}

    @Override
    public void present(double deltaTime) {
        Graphics g = game.getGraphics();

        if (state == GameState.Running)
            drawRunningUI();
        if (state == GameState.GameOver)
            drawGameOverUI();

    }

    private void drawRunningUI() {
        Graphics g = game.getGraphics();
        g.drawPixmap(Assets.buttons, 0, 0, 0, 193, 32, 32);
    }

    public void drawGameOverUI() {
        Graphics g = game.getGraphics();
        if(win.equals(user)){
            g.drawPixmap(Assets.wintext, 50, 200);

    }
       if(win.equals(computer)){
            g.drawPixmap(Assets.losetext, 50, 200);

        }
        if(win.equals("draw")){
            g.drawPixmap(Assets.drawtext, 75, 200);
        }

    }

    private void drawGameWorld() {
        Graphics g = game.getGraphics();

        g.drawPixmap(Assets.background, 0, 0);
        g.drawPixmap(Assets.tic_tac_toe_board, 35, 50, 0, 0, 250, 350);
        g.drawPixmap(Assets.X, 130, 350, 0, 0, 63, 59);
        g.drawPixmap(Assets.O, 130, 400, 0, 0, 60, 58);
        g.drawPixmap(Assets.buttons, 250, 0, 0, 0, 63, 60);
    }


    public void drawSymbol(String val, int x_cor, int y_cor){
        Graphics g = game.getGraphics();
        if (val.equals("X")) {
            g.drawPixmap(Assets.X, xCords[x_cor], yCords[y_cor]);
            count--;
        }
        if(val.equals("O")){
            g.drawPixmap(Assets.O, xCords[x_cor], yCords[y_cor]);
            count--;
        }
        checkGame();
        if(val.equals(user) && win.equals("null")){
            if(count>1 && count<9) {
                    computerTurn();
                }

        }
    }


    public void checkSquare(int x, int y) {
        if (currentBoard[x][y] == null) {
            currentBoard[x][y]=user;
            drawSymbol(user, x, y);

        }
    }


    public void getSquare(int x, int y) {
        int boardx = 0, boardy = 0;
        for (int i = 0; i < 3; i++) {
            if (x > xCords[i]) {
                boardx = i;
            }
        }
        for (int j = 0; j < 3; j++) {
            if (y > yCords[j]) {
                boardy = j;
            }
        }
        checkSquare(boardx, boardy);
    }


    public void computerTurn(){
        int num1, num2;
        boolean bool=false;
        while(bool==false){
            num1=new Random().nextInt(3);
            num2=new Random().nextInt(3);
            if (currentBoard[num1][num2]==null){
                bool=true;
                currentBoard[num1][num2]=computer;
                drawSymbol(computer, num1, num2);

            }
        }

        }

    public void checkGame() {
        for (int a = 0; a < 3; a++) {
            if (currentBoard[a][0]==user && currentBoard[a][1]==user && currentBoard[a][2]==user) {
                win = user;
                gameOver = true;
                if (Settings.soundEnabled) Assets.winGame.play(1);
                return;

            }  else if (currentBoard[a][0]==computer && currentBoard[a][1]==computer && currentBoard[a][2]==computer) {
                win = computer;
                gameOver = true;
                if (Settings.soundEnabled) Assets.loseGame.play(1);
                return;
            }
        }
        for (int b = 0; b < 3; b++) {
            if (currentBoard[0][b]==user && currentBoard[1][b]==user && currentBoard[2][b]==user){
                win = user;
                gameOver = true;
                if (Settings.soundEnabled) Assets.winGame.play(1);
                return;
            }
            else if (currentBoard[0][b]==computer && currentBoard[1][b]==computer && currentBoard[2][b]==computer){
                win = computer;
                gameOver = true;
                if (Settings.soundEnabled) Assets.loseGame.play(1);
                return;
            }
        }
        if (currentBoard[0][0]==user && currentBoard[1][1]==user && currentBoard[2][2]==user) {
            win = user;
            gameOver = true;
            if (Settings.soundEnabled) Assets.winGame.play(1);
        } else if (currentBoard[0][0]==computer && currentBoard[1][1]==computer && currentBoard[2][2]==computer) {
            win = computer;
            gameOver = true;
            if (Settings.soundEnabled) Assets.loseGame.play(1);
        }
        else if (currentBoard[2][0]==user && currentBoard[1][1]==user && currentBoard[0][2]==user) {
            win = user;
            gameOver = true;
            if (Settings.soundEnabled) Assets.winGame.play(1);
        } else if (currentBoard[2][0]==computer && currentBoard[1][1]==computer && currentBoard[0][2]==computer) {
            win = computer;
            gameOver = true;
            if (Settings.soundEnabled) Assets.loseGame.play(1);
        }
        else if (currentBoard[0][0]!=null && currentBoard[0][1]!=null && currentBoard[0][2]!=null && currentBoard[1][0]!=null && currentBoard[1][1]!=null
                && currentBoard[1][2]!=null&& currentBoard[2][0]!=null && currentBoard[2][1]!=null && currentBoard[2][2]!=null){
            win = "draw";
            gameOver = true;
        }}



            @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void dispose() {
        Settings.addScore(win, user, computer);
        Settings.save(game.getFileIO());

    }

    private boolean inBounds(Input.TouchEvent event, int x, int y, int width, int height) {
        if(event.x > x && event.x < x + width - 1 && event.y > y && event.y < y + height - 1) {
            return true;
        }
        else
            return false;
    }}
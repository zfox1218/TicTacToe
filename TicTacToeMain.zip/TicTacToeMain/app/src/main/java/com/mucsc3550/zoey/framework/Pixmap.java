package com.mucsc3550.zoey.framework;

import com.mucsc3550.zoey.framework.Graphics.PixmapFormat;

public interface Pixmap {
    public int getWidth();

    public int getHeight();

    public PixmapFormat getFormat();

    public void dispose();
}

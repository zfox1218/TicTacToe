package com.mucsc3550.zoey.framework;

import com.mucsc3550.zoey.framework.Input.TouchEvent;

import java.util.List;

public class HelpScreen3 extends Screen {
    public HelpScreen3(Game game) {
        super(game);
    }

    @Override
    public void update(double deltaTime) {
        List<TouchEvent> touchEvents = game.getInput().getTouchEvents();
        int len = touchEvents.size();
        for(int i = 0; i < len; i++) {
            TouchEvent event = touchEvents.get(i);
            if(event.type == TouchEvent.TOUCH_UP) {
                if(event.x > 256 && event.y > 410) {
                    game.setScreen(new HelpScreen4(game));
                    if(Settings.soundEnabled)
                        Assets.click.play(1);
                }
                if (inBounds(event, 257, 0, 63, 60)) {
                    if (Settings.soundEnabled) Assets.click.play(1);
                    game.setScreen(new MainMenuScreen(game));
                }
            }
        }
    }

    @Override
    public void present(double deltaTime) {
        Graphics g = game.getGraphics();

        g.drawPixmap(Assets.background, 0, 0);
        g.drawPixmap(Assets.help3, 64, 100);
        g.drawPixmap(Assets.buttons, 256, 410, 0, 64, 64, 64);
        g.drawPixmap(Assets.buttons, 250, 0, 0, 0, 63, 60);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void dispose() {

    }
    private boolean inBounds(TouchEvent event, int x, int y, int width, int height) {
        if(event.x > x && event.x < x + width - 1 && event.y > y && event.y < y + height - 1) {
            return true;
        }
        else
            return false;
    }
}

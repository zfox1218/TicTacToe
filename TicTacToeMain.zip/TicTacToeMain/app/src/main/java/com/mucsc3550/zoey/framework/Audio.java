package com.mucsc3550.zoey.framework;

public interface Audio {
    Music newMusic(String filename);

    Sound newSound(String filename);
}

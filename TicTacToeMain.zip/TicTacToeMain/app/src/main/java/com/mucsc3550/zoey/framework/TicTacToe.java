package com.mucsc3550.zoey.framework;

import com.mucsc3550.zoey.framework.impl.AndroidGame;

public class TicTacToe extends AndroidGame {

    public Screen getStartScreen() {
        return new LoadingScreen(this);
    }

}
